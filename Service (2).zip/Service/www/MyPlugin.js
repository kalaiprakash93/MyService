window.trackuserlocation = function(winParam,failParam) {
cordova.exec(winParam, failParam, "MyPlugin", "", []);
};
